## 1.Compile
```shell
cd g2o_example
mkdir build
cd build
cmake ..
make 
```

## 2.Run
```shell
cd build
./fit_curve
```

## 3.Display
```shell
python viewer.py
```
